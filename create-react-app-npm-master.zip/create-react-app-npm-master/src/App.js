import React                from 'react'

import YourComponent        from 'components/YourComponent'

class App extends React.Component {
  render() {
    return (
      <YourComponent>
        1
      </YourComponent>
    )
  }
}

export default App
